import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class nivel1_2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class nivel1_2 extends World
{
    public static long startTime = System.currentTimeMillis();
    /**
     * Constructor for objects of class nivel1_2.
     * 
     */
    public nivel1_2()
    {    
        super(800, 590, 1); // Crea un nuevo mundo con un tamaño específico
        String imagen="mapas/nivel1_2.jpg";
        setBackground(imagen); // Establece la imagen de fondo del mundo
        
        this.addObject(new pistola(pistola.hp,pistola.municion,pistola.atk,pistola.puntaje, pistola.fase),400,550);
        this.addObject(new zombie(), 300,180);
        this.addObject(new zombie(), 500,100);
        this.addObject(new zombie(), 400,350);
        this.addObject(new zombie(), 450,300);
        this.addObject(new zombie(), 450,200);
        this.addObject(new zombie(), 550,200);
        this.addObject(new raiz(), 400,200);
        this.addObject(new raiz(), 200,200);
        this.addObject(new raiz(), 250,200);
        this.addObject(new raiz(), 280,170);
        this.addObject(new jefe1(), 400,100);
    }
    
    public void act()
    {        
        setPaintOrder(recupera.class,jefe1.class,zombie.class,ogro.class,raiz.class, pistola.class);
        String puntos = String.valueOf(pistola.puntaje);
        showText("Puntos: "+puntos, 80, 50);
        String vida = String.valueOf(pistola.hp);
        showText("HP: "+vida, 80, 80);
        String municion = String.valueOf(pistola.municion);
        showText("Municion: "+municion, 80, 110);
        long estimatedTime = (System.currentTimeMillis() - startTime)/1000;
        
        showText("Tiempo: "+estimatedTime, 80, 150);
        if (pistola.posX > 700 && pistola.posY > 170 && pistola.posY < 210 )
        { // Verifica si el personaje está en la esquina superior derecha
        Greenfoot.setWorld(new loading());
        }
    }
}
