import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ogro here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ogro extends Actor
{
    public static long startTime = System.currentTimeMillis();
    public double hp;// la cantidad de puntos de vida del zombie
    public double atk;// la cantidad de daño que puede hacer el zombie
    public double spd;// la velocidad de movimiento del zombie
    public boolean sonido;// indica si se debe reproducir el sonido del zombie
    public double segundos;
    public boolean puedeMorder;
    public boolean aplicaHab;
    public static int posX;
    public static int posY;
    /**
     * Constructor de la clase zombie que inicializa los atributos del mismo.
     */
    public ogro()
    {
        hp=80*dificultad.diffHP;
        atk=25*dificultad.diffATK;
        spd=1;
        sonido=true;
        aplicaHab=true;
        puedeMorder=true;
    }
    
    /**
     * Método que se llama cada vez que se ejecuta un ciclo del juego y que contiene
     * el comportamiento del zombie.
     */
    public void act()
    {
        posX = getX();
        posY = getY();
        if(puedeMorder==true)
        {
            perseguir();// hace que el enemigo persiga al jugador
            sonido();// reproduce el sonido del enemigo
            morder();// hace que el enemigo le haga daño al jugador al morderlo
            morir();// verifica si el enemigo ha muerto y lo elimina del mundo si es el caso   
        }
        else
        {
            setLocation(this.getX(),this.getY());
        }
        //estimatedTime almacena el valor en segundos, para saber si pasaron x segundos se usa modulo (%)
        long estimatedTime = (System.currentTimeMillis() - startTime)/1000;
        if(estimatedTime%3==0 && hp < 80*dificultad.diffHP && aplicaHab==true)
        {
            aplicaHab=false;
            habilidad();
            sonido=true;
        }
        if(estimatedTime%3==2)
        {
            aplicaHab=true;
        }
    }
    /**
     * Método que hace que el zombie persiga al jugador.
     */
    public void perseguir()
    {
        Actor enemigo = getOneIntersectingObject(ogro.class);
        Actor enemigo2 = getOneIntersectingObject(ogroH.class);
        Actor enemigo3 = getOneIntersectingObject(paracito.class);
        Actor enemigo4 = getOneIntersectingObject(raiz.class);
        
        turnTowards(pistola.posX,pistola.posY);// hace que el zombie gire hacia el jugador
        
        if(enemigo!=null)
        {
            enemigo.move(2);
            this.move(-1);
        }
        if(enemigo2!=null)
        {
            enemigo2.move(2);
            this.move(-1);
        }
        if(enemigo3!=null)
        {
            enemigo3.move(2);
            this.move(-1);
        }
        if(enemigo4!=null)
        {
            enemigo4.move(2);
            this.move(-1);
        }
        else
        {
            move((int)this.spd);
        }
    }
    /**
     * Método que hace que el zombie le haga daño al jugador al morderlo.
     */
    public void morder()
    {
        Actor humano = getOneIntersectingObject(pistola.class);
        if(humano!=null && puedeMorder==true)// verifica si el zombie ha alcanzado al jugador
        {
            pistola.hp-=atk;// le hace daño al jugador
            this.move(-40);// hace que el zombie retroceda un poco después de morder al jugador
            Greenfoot.playSound("mordida.wav");
        }

    }
    /**
     * Método que verifica si el zombie ha muerto y lo elimina del mundo si es el caso.
     */
    public void morir()
    {
        Actor bala = getOneIntersectingObject(bala.class);
        if(bala!=null)// verifica si el zombie ha sido alcanzado por una bala
        {
            getWorld().removeObject(bala);// elimina la bala del mundo
            if(hp<=0)// verifica si el zombie ya ha muerto
            {
                //getWorld().addObject(new sangre(),this.getX() ,this.getY());
                Greenfoot.playSound("sangre.wav");
                pistola.puntaje+=25;
                getWorld().removeObject(this);   
            }
            else
            {
                hp-=pistola.atk;
            }
            if(hp<=0)
            {
                getWorld().addObject(new sangre(),this.getX() ,this.getY());// agrega un objeto de sangre al mundo en la posición del zombie
                Greenfoot.playSound("sangre.wav");
                pistola.puntaje+=25;// incrementa el puntaje del jugador
                this.spd=0;
                this.puedeMorder=false;
                getWorld().removeObject(this);
            }
        }
    }
    public void sonido()
    {
        if(sonido==true)
        {
            sonido=false;
            Greenfoot.playSound("ogro.wav");
        }
    }
    public void habilidad()
    {        
        getWorld().addObject(new recupera(), getX(), getY());
        
        if(hp+20>80)
        {
            hp=80;
        }
        else
        {
            hp=hp+20;   
        }
    }
}