import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase mejora representa un objeto que se puede recoger en el mundo.
 * Al ser creado, se escala su imagen a una quinta parte del tamaño original.
 * Se mueve a la posición del objeto pistola con una ligera compensación en X e Y.
 * Al presionar la tecla "u", se elimina este objeto del mundo.
 
 * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin 
 * @version 20-04-2023 

 */
public class mejora extends Actor
{
    mejora()
    {
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/5;
        int myNewWidth= (int)myImage.getWidth()/5;
        myImage.scale(myNewWidth,myNewHeight);
    }
    
    /**
     * Método que se llama cada vez que el botón "Act" o "Run" se presiona en el mundo.
     * Establece la ubicación de este objeto a la posición del objeto pistola con una compensación de coordenadas.
     * Si la tecla "u" está presionada, elimina este objeto del mundo.
     */
    public void act()
    {
        setLocation(pistola.posX+20,pistola.posY-25);
        if(Greenfoot.isKeyDown("u"))
        {
            getWorld().removeObject(this);
        }
    }
}
