import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Esta clase representa el mundo del juego, donde se desarrolla el juego y contiene objetos y personajes que interactúan entre sí.
 * 
 * El mundo del juego tiene un botón de dificultad que se puede presionar para establecer la dificultad del juego.
 * 
 * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin 
 * @version 20-04-2023
 */
public class MyWorld extends World
{
    /**
     * Constructor para objetos de la clase MyWorld. 
     * Crea un nuevo mundo con una resolución de 800x590 píxeles y un factor de escala de 1. 
     * Establece el fondo del mundo a una imagen llamada "inicio.png".
     */
    public MyWorld()
    {    
        super(800, 590, 1);
        String imagen="inicio.png";
        setBackground(imagen);
        //this.addObject(new pistola(),300,390);
        //450,330
        //300,390
    }
    
    /**
     * Se llama repetidamente en cada ciclo del juego y se utiliza para actualizar el estado del mundo.
     * 
     * Este método llama al método "difficult()" que se encarga de verificar si el botón de dificultad ha sido presionado.
     */
    public void act()
    {
        difficult();
    }
    
    /**
     * Verifica si el mouse está sobre el área del botón de dificultad y si se ha hecho clic en él.
     * Si se cumplen ambas condiciones, se crea un nuevo mundo llamado "dificultad()"
       que es donde se establece la dificultad del juego.
     */
    public void difficult()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if(mouse != null)
        {
            if(mouse.getX()>=300 && mouse.getX()<=450 
            && mouse.getY()>=330 && mouse.getY()<=390
            && Greenfoot.mouseClicked(null))
            {
                Greenfoot.setWorld(new dificultad());
            }
        }
    }
}
