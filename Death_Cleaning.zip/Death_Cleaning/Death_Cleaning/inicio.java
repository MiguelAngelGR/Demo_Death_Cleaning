import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase inicio es un mundo del juego que se crea al inicio del mismo 
   y contiene la imagen de fondo y un objeto pistola.
 * La clase tiene un método nivel1 que se ejecuta en cada frame del mundo y comprueba si el objeto pistola se encuentra
   en una posición específica. Si la pistola está en esa posición, el mundo cambia al siguiente nivel.
 
 * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin 
 * @version 20-04-2023 
 */
public class inicio extends World
{
    /**
     * Constructor para objetos de la clase inicio.
     * Crea un nuevo mundo con 800x590 celdas y establece la imagen de fondo y agrega un objeto pistola.
     */
    public inicio()
    {    
        super(800, 590, 1);
        String imagen="mapas/inicio.png";
        setBackground(imagen);
        
        this.addObject(new pistola(100,12,10,0,1),540,300);
        // (460,100); cambio de escenario
    }
    /**
     * Método que se ejecuta en cada frame del mundo y 
       comprueba si la pistola está en una posición específica.
     * Si la pistola está en esa posición, el mundo cambia al siguiente nivel (nivel1_1).
     */
    public void act()
    {
        nivel1();
    }
    /**
     * Método que comprueba si la pistola está en una posición específica. Si es así, cambia el mundo al siguiente nivel.
     */
    public void nivel1()
    {
        if(pistola.posX>440 && pistola.posX<480 && pistola.posY==100)
        {
            Greenfoot.setWorld(new nivel1_1());
        }
    }
}
