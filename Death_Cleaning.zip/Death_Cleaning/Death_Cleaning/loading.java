import greenfoot.*;

public class loading extends World {

    public loading() {
        super(800, 590, 1);
        setBackground("completado.jpeg");
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new nivel2_1()); // Reemplaza nivel1_3 con el siguiente nivel después de la pantalla de carga
        }
    }
}