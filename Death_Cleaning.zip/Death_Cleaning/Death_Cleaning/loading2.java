import greenfoot.*;

public class loading2 extends World {

    public loading2() {
        super(800, 590, 1);
        setBackground("nivelfinal.jpeg");
    }

    public void act() {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new nivel3_1()); 
        }
    }
}