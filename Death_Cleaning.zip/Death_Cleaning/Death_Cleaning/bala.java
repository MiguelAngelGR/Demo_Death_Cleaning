import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
    *La clase bala representa la bala disparada por la pistola en el juego.
    *La bala se mueve hacia adelante en línea recta desde la posición inicial
     y se destruye si llega a los límites del mundo.
    *También puede ser eliminada si colisiona con otros objetos en el mundo.
    
    * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin 
    * @version 20-04-2023 
 */
public class bala extends Actor
{    
    public bala(int angulo)
    {
        setRotation(angulo);
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()/2;
        int myNewWidth= (int)myImage.getWidth()/2;
        myImage.scale(myNewWidth,myNewHeight);
    }
    /**
     * Verifica si la bala ha alcanzado los límites del mundo.
     * Regresa true si la bala está en el límite del mundo,
     * Regresa false de lo contrario.
     */
    
    
    public boolean alLimite()
    {
        if(getX()<10 || getX()>getWorld().getWidth()-10)
            return true;
        if(getY()<10 || getY()>getWorld().getHeight()-10)
            return true;
        else 
            return false;
    }
    /**
    *El comportamiento de la bala en cada iteración del mundo.
    *La bala se mueve hacia adelante en línea recta y 
     se elimina si alcanza los límites del mundo.
    *También puede ser eliminada si colisiona con otros objetos en el mundo.
*/
    public void act()
    {
        World w = getWorldOfType(World.class);
        
        move(20);
        if(getWorld()!=null)
            if(getX()<10 || getX()>getWorld().getWidth()-10 || getY()<10 || 
            getY()>getWorld().getHeight()-10)
            {
                w.removeObject(this);
            }
        if(pistola.fase==2)
        {
            setImage("bala2.png");
        }
        if(pistola.fase==3)
        {
            setImage("bala3.png");
        }
    }
}
