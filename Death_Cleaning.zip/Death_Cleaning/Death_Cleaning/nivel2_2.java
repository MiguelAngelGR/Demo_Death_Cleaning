import greenfoot.*;

public class nivel2_2 extends World {
    public static long startTime = System.currentTimeMillis();
    private boolean nivelCompletado = false;

    public nivel2_2() {
        super(800, 590, 1);
        String imagen = "mapas/nivel2_2.jpg";
        setBackground(imagen);

        this.addObject(new pistola(pistola.hp, pistola.municion, pistola.atk, pistola.puntaje, pistola.fase), 400, 550);
        this.addObject(new ogro(), 300,180);
        this.addObject(new ogro(), 500,100);
        this.addObject(new paracito(), 400,350);
        this.addObject(new paracito(), 450,300);
        this.addObject(new paracito(), 450,200);
        this.addObject(new paracito(), 550,200);
        this.addObject(new raiz(), 400,200);
        this.addObject(new raiz(), 200,200);
        this.addObject(new raiz(), 250,200);
        this.addObject(new raiz(), 280,170);
        this.addObject(new jefe2(), 400,100);
    }

    public void act() {
        setPaintOrder(recupera.class, jefe2.class, ogro.class, raiz.class, pistola.class);
        String puntos = String.valueOf(pistola.puntaje);
        showText("Puntos: " + puntos, 80, 50);
        String vida = String.valueOf(pistola.hp);
        showText("HP: " + vida, 80, 80);
        String municion = String.valueOf(pistola.municion);
        showText("Municion: " + municion, 80, 110);
        long estimatedTime = (System.currentTimeMillis() - startTime) / 1000;
        showText("Tiempo: " + estimatedTime, 80, 150);
        if (pistola.posX > 700 && pistola.posY > 170 && pistola.posY < 210 ) { // Verifica si el personaje está en la esquina superior derecha
        Greenfoot.setWorld(new loading2());
        }
       
        
    }
   
}
