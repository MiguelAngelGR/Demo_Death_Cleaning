import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class paracito here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class paracito extends Actor
{
    public static long startTime = System.currentTimeMillis();
    public double hp;// la cantidad de puntos de vida del monstruo
    public double atk;// la cantidad de daño que puede hacer el monstruo
    public double spd;// la velocidad de movimiento del monstruo
    public boolean sonido;// indica si se debe reproducir el sonido del monstruo
    public boolean puedeMorder;
    public static int posX;
    public static int posY;
    public boolean aplicaHab;
    /**
     * Constructor de la clase paracito que inicializa los atributos del mismo.
     */
    public paracito()
    {
        hp=10*dificultad.diffHP;
        atk=5*dificultad.diffATK;
        spd=2;
        sonido=true;
        aplicaHab=true;
        puedeMorder=true;
    }
    
    /**
     * Método que se llama cada vez que se ejecuta un ciclo del juego y que contiene
     * el comportamiento del monstruo.
     */
    public void act()
    {
        posX = getX();
        posY = getY();
        //long currentTime = System.currentTimeMillis();
        if(puedeMorder==true)
        {
            perseguir();// hace que el zombie persiga al jugador
            sonido();// reproduce el sonido del monstruo
            morder();// hace que el monstruo le haga daño al jugador al morderlo
            morir();// verifica si el monstruo ha muerto y lo elimina del mundo si es el caso   
        }
        else
        {
            setLocation(this.getX(),this.getY());
        }
        long estimatedTime = (System.currentTimeMillis() - startTime)/1000;
        if(estimatedTime%3==0 && aplicaHab==true)
        {
            aplicaHab=false;
            sonido=true;
        }
        if(estimatedTime%3==2)
        {
            aplicaHab=true;
        }
    }
    /**
     * Método que hace que el monstruo persiga al jugador.
     */
    public void perseguir()
    {
        turnTowards(pistola.posX,pistola.posY);// hace que el monstruo gire hacia el jugador
        
        Actor enemigo = getOneIntersectingObject(paracito.class);
        Actor enemigo2 = getOneIntersectingObject(ogro.class);
        Actor enemigo3 = getOneIntersectingObject(ogroH.class);
        Actor enemigo4 = getOneIntersectingObject(raiz.class);
        
        if(enemigo!=null)
        {
            enemigo.move(2);
            this.move(-1);
        }
        if(enemigo2!=null)
        {
            enemigo2.move(2);
            this.move(-1);
        }
        if(enemigo3!=null)
        {
            enemigo3.move(2);
            this.move(-1);
        }
        if(enemigo4!=null)
        {
            enemigo4.move(2);
            this.move(-1);
        }
        else
        {
            move((int)this.spd);
        }
    }
    /**
     * Método que hace que el monstruo le haga daño al jugador al morderlo.
     */
    public void morder()
    {
        Actor humano = getOneIntersectingObject(pistola.class);
        if(humano!=null && puedeMorder==true)// verifica si el monstruo ha alcanzado al jugador
        {
            pistola.hp-=atk;// le hace daño al jugador
            this.move(-40);// hace que el monstruo retroceda un poco después de morder al jugador
            Greenfoot.playSound("mordida.wav");
        }

    }
    /**
     * Método que verifica si el monstruo ha muerto y lo elimina del mundo si es el caso.
     */
    public void morir()
    {
        Actor bala = getOneIntersectingObject(bala.class);
        if(bala!=null)// verifica si el monstruo ha sido alcanzado por una bala
        {
            getWorld().removeObject(bala);// elimina la bala del mundo
            if(hp<=0)// verifica si el monstruo ya ha muerto
            {
                //getWorld().addObject(new sangre(),this.getX() ,this.getY());
                Greenfoot.playSound("sangre.wav");
                pistola.puntaje+=5;
                getWorld().removeObject(this);   
            }
            else
                hp-=pistola.atk;
            if(hp<=0)
            {
                getWorld().addObject(new sangre(),this.getX() ,this.getY());// agrega un objeto de sangre al mundo en la posición del zombie
                Greenfoot.playSound("sangre.wav");
                pistola.puntaje+=5;// incrementa el puntaje del jugador
                this.spd=0;
                this.puedeMorder=false;
                getWorld().removeObject(this);
            }
        }
    }
    public void sonido()
    {
        if(sonido==true)
        {
            sonido=false;
            Greenfoot.playSound("parasito.wav");
        }
    }
}
