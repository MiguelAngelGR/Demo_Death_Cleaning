import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase pistola representa al personaje principal del juego.
 * Tiene atributos como salud, ataque, velocidad, municiones, puntaje y fase actual.
 * El personaje puede disparar y moverse con las teclas 'w', 'a', 's' y 'd'.
 * También puede recargar con la tecla 'r' y mejorar su arma con la tecla 'u' si tiene suficiente puntaje.
 * El personaje muere cuando su salud llega a cero.
 * Además, puede obtener recompensas en forma de mejoras de arma.
 
 * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin 
 * @version 20-04-2023 
 */
public class pistola extends Actor 
{
    public int jugadorRotacion;
    public static double hp;
    public static double atk;
    public static double spd;
    public static int municion;
    public boolean puedeDisparar;
    public static int posX;
    public static int posY;
    public static int puntaje;
    public boolean puedeMejorar;
    public static int fase;
 
    public pistola(double hpR,int municionR,double atkR,int puntajeR,int faseR)
    {
        
        puedeDisparar=true;
        puedeMejorar=false;
        municion=municionR;
        hp=hpR;
        atk=atkR;
        spd=2;
        puntaje=puntajeR;
        fase=faseR;
        //mide 40 puntos el personaje
    }
    /**
     * El método act() se llama cada vez que se presiona el 
       botón 'Act' o 'Run' en el entorno.
     * En este método se definen las acciones que el personaje puede realizar en cada momento.     
     */
    public void act()
    {
        // Obtiene la posición y la rotación actual del jugador
        MouseInfo mouse = Greenfoot.getMouseInfo();
        jugadorRotacion = getRotation();
        posX = getX();
        posY = getY();
        shoot();
        int x=recompensas();// Verifica si el jugador ha recolectado una mejora
        die();// Verifica si el jugador ha muerto
        if(mouse != null)
        {
            turnTowards(mouse.getX(), mouse.getY());
        }
        // Verifica si se presionó una tecla para mover al jugador
        if(Greenfoot.isKeyDown("a")){
            setLocation(getX()-(int)this.spd,getY());
        }
        if(Greenfoot.isKeyDown("d")){
            setLocation(getX()+(int)this.spd,getY());
        }
        if(Greenfoot.isKeyDown("w")){
            setLocation(getX(),getY()-(int)this.spd);
        }
        if(Greenfoot.isKeyDown("s")){
            setLocation(getX(),getY()+(int)this.spd);
        }
        // Verifica si se presionó la tecla "r" para recargar el arma
        if(Greenfoot.isKeyDown("r") && puedeDisparar==false){
            if(fase==1)
            {
                Greenfoot.playSound("recarga.wav");
                this.municion=12;
                puedeDisparar=true;         
            }
            if(fase==2)
            {
                Greenfoot.playSound("recarga_subfusil.wav");
                this.municion=24;
                puedeDisparar=true;    
            }
            if(fase==3)
            {
                Greenfoot.playSound("recarga_fusil.wav");
                this.municion=30;
                puedeDisparar=true;    
            }
        }
        // Verifica si se presionó la tecla "u" para mejorar el arma
        if(Greenfoot.isKeyDown("u") && puedeMejorar==true)
        {
            if(fase==1 && puntaje>=300)
            {
                setImage("jugador_subfusil.png");
                this.municion=24;
                this.fase=2;
                puedeMejorar=false;    
                puedeDisparar=true;
            }
            if(fase==2 && puntaje>=500)
            {
                setImage("jugador_asalto.png");
                this.municion=30;
                this.atk=20;
                this.fase=3;
                puedeMejorar=false;
                puedeDisparar=true;
            }
        }
    }
    
    public void shoot()
    {
        // Verifica si hay suficiente munición y si el jugador puede disparar
        if(municion>0 && puedeDisparar==true)
        {
            // Verifica si se hizo clic en el mouse y dispara un proyectil en la dirección del jugador
            if(Greenfoot.mouseClicked(null))
            {
                // Dependiendo de la fase del juego, reproduce un sonido y 
                //agrega un objeto bala en la dirección del jugador
                if(fase==1)
                {
                    Greenfoot.playSound("disparo.wav");
                    MouseInfo mouse = Greenfoot.getMouseInfo();
                    getWorld().addObject(new bala(jugadorRotacion), getX(), getY());
                    municion--;
                }
                if(fase==2)
                {
                    Greenfoot.playSound("disparo_subfusil.wav");
                    MouseInfo mouse = Greenfoot.getMouseInfo();
                    getWorld().addObject(new bala(jugadorRotacion), getX(), getY());
                    municion--;
                }
                if(fase==3)
                {
                    Greenfoot.playSound("disparo_fusil.wav");
                    MouseInfo mouse = Greenfoot.getMouseInfo();
                    getWorld().addObject(new bala(jugadorRotacion), getX(), getY());
                    municion--;
                }
            }    
        }
        else
        {
            puedeDisparar=false;
        }
    }
    
    public void die()
    {
        // Verifica si el jugador ha perdido toda su salud y muestra la pantalla de "Game Over"
        if(hp<=0)
        {
            this.hp=0;
            getWorld().addObject(new game_over(), 400, 285);
            Greenfoot.stop();
        }
    }
    public int recompensas()
    {
        // Verifica si el jugador ha alcanzado un puntaje suficientemente alto para obtener una mejora,
        //y agrega un objeto mejora en su posición
        if(puntaje>=300 && puedeMejorar==false && fase==1)
            {
            getWorld().addObject(new mejora(), getX()+100, getY()+50);
            puedeMejorar=true;
            return (1);
            }
        if(puntaje>=500 && puedeMejorar==false && fase==2)
            {
            getWorld().addObject(new mejora(), getX()+100, getY()+50);
            puedeMejorar=true;
            return (1);
            }
            return (0);
    }
}
