import greenfoot.*;

public class nivel3_2 extends World {
    public static long startTime = System.currentTimeMillis();
    private boolean nivelCompletado = false;

    public nivel3_2() {
        super(800, 590, 1);
        String imagen = "mapas/nivel3_2.jpg";
        setBackground(imagen);

        this.addObject(new pistola(pistola.hp, pistola.municion, pistola.atk, pistola.puntaje, pistola.fase), 400, 550);
        this.addObject(new ogro(), 300,180);
        this.addObject(new ogro(), 500,100);
        this.addObject(new ogro(), 400,350);
        this.addObject(new miron(), 450,200);
        this.addObject(new miron(), 550,200);
        this.addObject(new miron(), 400,200);
        this.addObject(new miron(), 200,200);
        this.addObject(new jefe3(), 400,100);
        
    }

    public void act() {
        setPaintOrder(recupera.class, jefe3.class, ogro.class, miron.class, pistola.class);
        String puntos = String.valueOf(pistola.puntaje);
        showText("Puntos: " + puntos, 80, 50);
        String vida = String.valueOf(pistola.hp);
        showText("HP: " + vida, 80, 80);
        String municion = String.valueOf(pistola.municion);
        showText("Municion: " + municion, 80, 110);
        long estimatedTime = (System.currentTimeMillis() - startTime) / 1000;
        showText("Tiempo: " + estimatedTime, 80, 150);
        
       
        
    }
   
}
