import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class nivel1_2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class nivel3_1 extends World
{
    public static long startTime = System.currentTimeMillis();
    /**
     * Constructor for objects of class nivel1_2.
     * 
     */
    public nivel3_1()
    {    
        super(800, 590, 1); 
        String imagen="mapas/nivel3_1.jpg";
        setBackground(imagen);
        
        this.addObject(new pistola(100,pistola.municion,pistola.atk,pistola.puntaje, pistola.fase),50,300);
        
    }
    
    public void act()
    {        
        setPaintOrder(recupera.class,jefe1.class,zombie.class, pistola.class);
        String puntos = String.valueOf(pistola.puntaje);
        showText("Puntos: "+puntos, 80, 50);
        String vida = String.valueOf(pistola.hp);
        showText("HP: "+vida, 80, 80);
        String municion = String.valueOf(pistola.municion);
        showText("Municion: "+municion, 80, 110);
        
        long estimatedTime = (System.currentTimeMillis() - startTime)/1000;
        
        showText("Tiempo: "+estimatedTime, 80, 150);
        if (pistola.posX > 700 && pistola.posY > 275 && pistola.posY < 325 ) { // Verifica si el personaje está en la esquina superior derecha
        Greenfoot.setWorld(new nivel3_2());
        }
        
    }
}