import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
  * Clase que representa al zombie que persigue al jugador y hace daño al morderlo.
 
 * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin 
 * @version 20-04-2023 
 */
public class zombie extends Actor
{
    public double hp;// la cantidad de puntos de vida del zombie
    public double atk;// la cantidad de daño que puede hacer el zombie
    public double spd;// la velocidad de movimiento del zombie
    public boolean sonido;// indica si se debe reproducir el sonido del zombie
    public boolean puedeMorder;
    public static int posX;
    public static int posY;
    /**
     * Constructor de la clase zombie que inicializa los atributos del mismo.
     */
    public zombie()
    {
        hp=20*dificultad.diffHP;
        atk=10*dificultad.diffATK;
        spd=1;
        sonido=true;
        puedeMorder=true;
    }
    
    /**
     * Método que se llama cada vez que se ejecuta un ciclo del juego y que contiene
     * el comportamiento del zombie.
     */
    public void act()
    {
        posX = getX();
        posY = getY();
        //long currentTime = System.currentTimeMillis();
        if(puedeMorder==true)
        {
            perseguir();// hace que el zombie persiga al jugador
            sonido();// reproduce el sonido del zombie
            morder();// hace que el zombie le haga daño al jugador al morderlo
            morir();// verifica si el zombie ha muerto y lo elimina del mundo si es el caso   
        }
        else
        {
            setLocation(this.getX(),this.getY());
        }
    }
    /**
     * Método que hace que el zombie persiga al jugador.
     */
    public void perseguir()
    {
        Actor enemigo = getOneIntersectingObject(zombie.class);
        
        turnTowards(pistola.posX,pistola.posY);// hace que el zombie gire hacia el jugador
        
        if(enemigo!=null)
        {
            enemigo.move(2);
            this.move(-1);
        }
        else
        {
            move((int)this.spd);
        }
    }
    /**
     * Método que hace que el zombie le haga daño al jugador al morderlo.
     */
    public void morder()
    {
        Actor humano = getOneIntersectingObject(pistola.class);
        if(humano!=null && puedeMorder==true)// verifica si el zombie ha alcanzado al jugador
        {
            pistola.hp-=atk;// le hace daño al jugador
            this.move(-40);// hace que el zombie retroceda un poco después de morder al jugador
            Greenfoot.playSound("mordida.wav");
        }

    }
    /**
     * Método que verifica si el monstruo ha muerto y lo elimina del mundo si es el caso.
     */
    public void morir()
    {
        Actor bala = getOneIntersectingObject(bala.class);
        if(bala!=null)// verifica si el zombie ha sido alcanzado por una bala
        {
            getWorld().removeObject(bala);// elimina la bala del mundo
            if(hp<=0)// verifica si el zombie ya ha muerto
            {
                //getWorld().addObject(new sangre(),this.getX() ,this.getY());
                Greenfoot.playSound("sangre.wav");
                pistola.puntaje+=10;
                getWorld().removeObject(this);   
            }
            else
                hp-=pistola.atk;
            if(hp<=0)
            {
                getWorld().addObject(new sangre(),this.getX() ,this.getY());// agrega un objeto de sangre al mundo en la posición del zombie
                Greenfoot.playSound("sangre.wav");
                pistola.puntaje+=10;// incrementa el puntaje del jugador
                this.spd=0;
                this.puedeMorder=false;
                getWorld().removeObject(this);
            }
        }
    }
    public void sonido()
    {
        if(sonido==true)
        {
            Greenfoot.playSound("zombie_sonido.wav");
            sonido=false;
        }
    }
}
