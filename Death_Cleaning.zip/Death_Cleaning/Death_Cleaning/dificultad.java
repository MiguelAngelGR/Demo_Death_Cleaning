import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase `dificultad` representa el mundo donde el jugador puede seleccionar la dificultad del juego.
 * Los valores de dificultad se pueden seleccionar haciendo clic en uno de los tres botones disponibles.
 * Una vez que se selecciona la dificultad, se almacena en las variables de clase `diffHP` y `diffATK`.
 
 * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin
 * @version 20-04-2023
 */
public class dificultad extends World
{
    public static int diffHP; // Almacena el multiplicador de puntos de vida según la dificultad seleccionada.
    public static int diffATK; // Almacena el multiplicador de puntos de ataque según la dificultad seleccionada.
    
    /**
     * Constructor para objetos de la clase `dificultad`.
     * Se crea un nuevo mundo con una imagen de fondo y se agregan tres botones para seleccionar la dificultad.
     */
    public dificultad()
    {    
        super(800, 590, 1);
        String imagen="dificultad.png";
        setBackground(imagen);
        
        this.addObject(new dif1(),230,230);
        this.addObject(new dif2(),410,290);
        this.addObject(new dif3(),550,210);
    }
    
    /**
     * El método `act()` se ejecuta constantemente mientras se muestra este mundo.
     * Llama al método `botones()` para detectar si se ha hecho clic en alguno de los botones de dificultad.
     */
    public void act()
    {
        botones();
    }
    
    /**
     * El método `botones()` verifica si se ha hecho clic en alguno de los tres botones de dificultad.
     * Si se hace clic en un botón, se establece la dificultad correspondiente y se inicia el mundo `inicio`.
     */
    public void botones()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if(mouse != null)
        {
            //dificultad 1, todo multiplicado por 1
            if(mouse.getX()>=150 && mouse.getX()<=330 
            && mouse.getY()>=200 && mouse.getY()<=240
            && Greenfoot.mouseClicked(null))
            {
                diffHP=1;
                diffATK=1;
                Greenfoot.setWorld(new inicio());
            }
            //dificultad 2, todo multiplicado por 2
            if(mouse.getX()>=330 && mouse.getX()<=510 
            && mouse.getY()>=260 && mouse.getY()<=300
            && Greenfoot.mouseClicked(null))
            {
                diffHP=2;
                diffATK=2;
                Greenfoot.setWorld(new inicio());
            }
            //dificultad 3, ataque multiplicado por 2 y vida por 4
            if(mouse.getX()>=470 && mouse.getX()<=650 
            && mouse.getY()>=180 && mouse.getY()<=220
            && Greenfoot.mouseClicked(null))
            {
                diffHP=4;
                diffATK=2;
                Greenfoot.setWorld(new inicio());
            }
        }
    }
}
