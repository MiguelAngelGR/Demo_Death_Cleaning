import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase dif1: representa un botón de la pantalla de selección de dificultad.
 * Cuando se hace clic sobre él, se carga la pantalla de selección de dificultad.
 * 
 * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin 
 * @version 20-04-2023 
 */
public class dif1 extends Actor
{
    /**
     * Método act: se ejecuta en cada ciclo del juego y detecta si se
     * ha hecho clic sobre el botón de dificultad.
     */
    public void act()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if(mouse != null)
        {
            if(mouse.getX()>=300 && mouse.getX()<=450 
            && mouse.getY()>=330 && mouse.getY()<=390
            && Greenfoot.mouseClicked(null))
            {
                Greenfoot.setWorld(new dificultad());
            }
        }
    }
}
