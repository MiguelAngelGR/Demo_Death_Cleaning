import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * La clase nivel1_1 es una subclase de la clase World de Greenfoot que representa el primer nivel del juego.
 * En este nivel, el jugador debe disparar a los zombies para obtener puntos y avanzar al siguiente nivel.
 * Esta clase maneja la creación de los objetos en el mundo y muestra el puntaje, la vida y la munición del jugador en la pantalla.
 * También contiene un método para cambiar al siguiente nivel si el jugador llega a una cierta posición en el mundo.
 * 
 * @author Miguel Angel Gonzales Reyes, Arturo Lopez Capin 
 * @version 20-04-2023 
 */
public class nivel1_1 extends World
{
    public static long startTime = System.currentTimeMillis();
    /**
     * Constructor de la clase nivel1_1.
     * Crea un nuevo mundo con una imagen de fondo y agrega objetos al mismo.
     * También inicializa el puntaje, la vida y la munición del jugador.
     */
    public nivel1_1()
    {    
        super(800, 590, 1); // Crea un nuevo mundo con un tamaño específico
        String imagen="mapas/nivel1_1.jpg";
        setBackground(imagen); // Establece la imagen de fondo del mundo
        
        this.addObject(new pistola(pistola.hp,pistola.municion,pistola.atk,pistola.puntaje, pistola.fase),400,500);
        this.addObject(new zombie(), 300,180);
        this.addObject(new zombie(), 500,100);
        this.addObject(new zombie(), 400,350);
        this.addObject(new zombie(), 450,300);
        this.addObject(new zombie(), 450,200);
        this.addObject(new zombie(), 550,200);
        this.addObject(new raiz(), 400,200);
        this.addObject(new raiz(), 200,200);
        this.addObject(new raiz(), 250,200);
        this.addObject(new raiz(), 280,170);
    }
    /**
     * El método act se llama automáticamente en cada fotograma.
     * Este método muestra el puntaje, la vida y la munición del jugador en la pantalla.
     */
    public void act()
    {
        setPaintOrder(zombie.class, raiz.class, pistola.class);
        String puntos = String.valueOf(pistola.puntaje);
        showText("Puntos: "+puntos, 80, 50);
        String vida = String.valueOf(pistola.hp);
        showText("HP: "+vida, 80, 80);
        String municion = String.valueOf(pistola.municion);
        showText("Municion: "+municion, 80, 110);
        nivel1_2();
    }
    /**
     * El método nivel1_2 se llama cuando el jugador llega a una cierta posición en el mundo.
     * Este método cambia al siguiente nivel y reinicia la posición del jugador.
     */
    public void nivel1_2()
    {
        if(pistola.posX>240 && pistola.posX<600 && pistola.posY>0 && pistola.posY<40)
        {
            
            Greenfoot.setWorld(new nivel1_2());
            this.addObject(new pistola(pistola.hp,pistola.municion,pistola.atk,pistola.puntaje, pistola.fase),540 ,150);
        }
    }
}
